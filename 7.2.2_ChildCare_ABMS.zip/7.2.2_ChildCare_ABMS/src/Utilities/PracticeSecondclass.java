package Utilities;

public class PracticeSecondclass {

	public static void main(String[] args) {

		PraciceFirstclass ABC= new PraciceFirstclass();
				ABC.sub();
				
	}

}
