package Utilities;

import org.apache.commons.lang3.RandomStringUtils;

public class CreateRandomNames {

	public String setRandomFirstName(int length)
	{
		return RandomStringUtils.randomAlphabetic(length);
	}
	
	public String setRandomLastName(int length)
	{
		return RandomStringUtils.randomAlphabetic(length);
	}
	
	public String setSSN()
	
	{
		
		
		String fir=RandomStringUtils.randomNumeric(3);
		
		
		if(fir.startsWith("9"))
		
			fir=fir.replace('9', '6');
		
		
		
			
		String sec=RandomStringUtils.randomNumeric(2);
		String third=RandomStringUtils.randomNumeric(4);;
		
		
		String ssn= fir +"-" + sec + "-" + third;
		
		return ssn;
	}
	
}
