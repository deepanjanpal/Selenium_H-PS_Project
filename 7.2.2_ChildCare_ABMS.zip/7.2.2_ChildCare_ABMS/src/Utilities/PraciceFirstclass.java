package Utilities;

public class PraciceFirstclass {

	public void sub() {

		int i=10;
		
		do {
			
			System.out.println("asddf" + i);
			i++;
		}
		
		while(i<20);
			
			
		
		

}

}