package Utilities;

import org.apache.commons.lang3.RandomStringUtils;

public class GenerateAddress {

	public String setAddressLine1(int length)
	{
		return RandomStringUtils.randomAlphabetic(length);
	}
	
	public String setAddressLine2(int length)
	{
		return RandomStringUtils.randomAlphabetic(length);
	}
	
	
	
	
}

