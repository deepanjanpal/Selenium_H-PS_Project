package Utilities;

import java.sql.*;

import org.testng.Assert;

import org.testng.annotations.Test;


public class ConnectDB {

	@Test
	public void testDB() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Class Loaded");
		Connection connection = null;
		connection = DriverManager.getConnection("jdbc:oracle:thin:@//10.3.31.209:1521/APSMOC01","abmsuser","Aust1n");
		System.out.println("Connected");
		
		
		Statement stmt=connection.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from pers where first_name='Wookie'");
		
		String lname=null;
		if(rs.next())
		{
			lname=rs.getString(2);
			System.out.println("" + lname);
		}
		
        Assert.assertEquals("Cookie", lname);
        System.out.println("Matched");
	}
}
