package abms_datacollection_navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ABMS_DC_Navigation {

	WebDriver driver;
	
	public ABMS_DC_Navigation(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By IndDemo=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr[4]/td/table/tbody/tr[6]/td/table/tbody/tr/td/div/ul/li[1]/div[2]/ul/li[3]/a/span");
	By VitalStats=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr[4]/td/table/tbody/tr[6]/td/table/tbody/tr/td/div/ul/li[1]/div[2]/ul/li[4]/a/span");
	
	By Relationship=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr[4]/td/table/tbody/tr[6]/td/table/tbody/tr/td/div/ul/li[1]/div[2]/ul/li[6]/a/span");
	By Verification=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr[4]/td/table/tbody/tr[6]/td/table/tbody/tr/td/div/ul/li[6]/a/span");
	
	By RunEDBC=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr[4]/td/table/tbody/tr[6]/td/table/tbody/tr/td/div/ul/li[8]/a/span");
	public void clickIndDemo()
	{
		driver.findElement(IndDemo).click();
	}
	
	public void clickVitalStats()
	{
		driver.findElement(VitalStats).click();
	}
	
	public void clickRelationship()
	{
		driver.findElement(Relationship).click();
	}
	
	public void clickVerifications()
	{
		driver.findElement(Verification).click();
	}
	
	public void clickRunEDBC()
	{
		driver.findElement(RunEDBC).click();
	}
}
