
public class Firstclass {

	public void add(){
		
		int i=20;
		int j=90;
		
		int k=i+j;
		
		System.out.println("Addition of I+J=" + k);
		

		
	}

}
