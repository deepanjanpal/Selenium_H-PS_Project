package abms_pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CaseMemberList {

	WebDriver driver;
	
	public CaseMemberList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By AddPerson=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[1]/td[2]/a[1]/img");
	
	By Remove=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[5]/td[1]/a/img");

    By SaveandContinue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[5]/td[2]/a[2]/img");
    
    
    public void clickAddPerson()
    {
    	driver.findElement(AddPerson).click();
    }
    
    public void clickRemove()
    {
    	driver.findElement(Remove).click();
    }
    
    public void clickSaveandContinue()
    {
    	driver.findElement(SaveandContinue).click();
    }
}
