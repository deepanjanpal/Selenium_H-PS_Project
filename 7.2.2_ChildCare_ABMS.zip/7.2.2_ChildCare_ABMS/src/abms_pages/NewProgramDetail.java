package abms_pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class NewProgramDetail {

	WebDriver driver;
	
	public NewProgramDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By Primary=By.id("primaryId");
	By DateofApplication=By.id("Application");
	By Language=By.id("Language");
	
	By Add1=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[3]/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[4]/a/img");
	By Add2=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[3]/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[3]/td[4]/a/img");
	
	By SaveandContinue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/div[1]/a/img");
	By Cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[3]/a/img");
	
	By ExpeditedServQuestion=By.id("expeditedFoodServices");
	
	public void selectPrimary()
	{
		Select primary=new Select(driver.findElement(Primary));
		primary.selectByIndex(1);
	}
	
	public void dateofApplication()
		
		{
			
			driver.findElement(DateofApplication).sendKeys("01/01/2016");
		}
		
		public void clickAddPrimar()
		{
		
				
				driver.findElement(Add1).click();
			}
			
		public void clickAddSecond()
		{
		
				
				driver.findElement(Add2).click();
			}
			public void selectExpedQuestion()
			{
				Select exped=new Select(driver.findElement(ExpeditedServQuestion));
				exped.selectByIndex(1);
			}
			
		public void SaveandContinue()
		{
			driver.findElement(SaveandContinue).click();
		}


}
