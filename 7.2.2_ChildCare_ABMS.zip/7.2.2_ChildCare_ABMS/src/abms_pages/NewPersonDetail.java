package abms_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class NewPersonDetail {
	
	WebDriver driver;
	
	public NewPersonDetail(WebDriver driver)
	
	{
      this.driver=driver;
   }
	
	By DOB=By.id("dob");
	By Search=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[4]/td/table/tbody/tr[6]/td[2]/span[2]/a/img");
	By Add_Address=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[4]/td/table/tbody/tr[7]/td/table/tbody/tr[2]/td[2]/a/img");
	By SaveandContinue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[1]/td[2]/a/img");
	
	
	public void enterDOB()
	{
		driver.findElement(DOB).sendKeys("");
	
	}
	
	public void clickAddAddress()
	{
		driver.findElement(Add_Address).click();
	
	}
	
	public void clickSearch()
	{
		driver.findElement(Search).click();
	
	}
	
	public void clickSaveandContinue()
	{
		driver.findElement(SaveandContinue).click();
	
	}
}
