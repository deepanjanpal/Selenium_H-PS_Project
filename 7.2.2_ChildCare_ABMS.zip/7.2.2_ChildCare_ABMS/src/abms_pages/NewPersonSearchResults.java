package abms_pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewPersonSearchResults {
	
	WebDriver driver;
	
	By Select=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table/tbody/tr[1]/td/a[1]/img");
	By AddNewPerson=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table/tbody/tr[1]/td/a[1]/img");
    By Cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table/tbody/tr[1]/td/a[2]/img");
    
    
    public NewPersonSearchResults(WebDriver driver)
	{
		this.driver=driver;
	}
    
    public void clickSelect()
    
    {
    	driver.findElement(Select).click();
    }
    
public void clickAddNewPerson()
    
    {
	driver.findElement(AddNewPerson).click();
    }

public void clickCancel()

{
	driver.findElement(Cancel).click();
}

}
