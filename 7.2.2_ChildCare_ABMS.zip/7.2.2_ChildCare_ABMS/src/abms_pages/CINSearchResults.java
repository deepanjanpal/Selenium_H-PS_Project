package abms_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CINSearchResults {

WebDriver driver;
	
	public CINSearchResults(WebDriver driver)
	
	{
      this.driver=driver;
   }
	
	By Select=By.id("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/form/table[2]/tbody/tr/td/a[1]/img");
	By RequestNewCIN=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/form/table[2]/tbody/tr/td/a[1]/img");
	By Cancel= By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table/tbody/tr/td/form/table[2]/tbody/tr/td/a[2]/img");
	
	public void clickSelect()
	{
		driver.findElement(Select).click();
	
	}
	
	public void clickRequestNewCIN()
	{
		driver.findElement(RequestNewCIN).click();
	
	}
	
	public void clickCancel()
	{
		driver.findElement(Cancel).click();
	
	}
	
	
}

