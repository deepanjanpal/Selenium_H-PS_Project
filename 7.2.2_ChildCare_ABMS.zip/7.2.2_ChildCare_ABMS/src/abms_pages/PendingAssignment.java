package abms_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class PendingAssignment {

	WebDriver driver;
	
	public PendingAssignment(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By selectAll=By.id("selectAll");
	
	By assign=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[1]/img");

	By Close=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[2]/img");
	
	public void clickselectAll()
	{
		driver.findElement(selectAll).click();
	}
	
	public void clickAssign()
	{
		driver.findElement(assign).click();
	}
	
	public void clickClose()
	{
		driver.findElement(Close).click();
	}
	
}
