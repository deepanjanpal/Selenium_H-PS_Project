package abms_pages;

import Utilities.CreateRandomNames;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.ui.Select;

public class NewPersonSearch {
	
	WebDriver driver;
	
	public NewPersonSearch(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	CreateRandomNames crandname=new CreateRandomNames();
	By LastName=By.id("lastName");
	By FirstName=By.id("firstName");
	By MiddleName=By.id("midName");
	By Suffix=By.id("suffix");
	By SSN=By.id("Ssn");
	By DOB=By.id("dob");
	By AlienNumber=By.id("alienNumber");
	By Gender=By.id("gender");
	
	By Search=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr/td[3]/a/img");
	
	
	
	public void enterLastName()
	{
		driver.findElement(LastName).sendKeys(crandname.setRandomLastName(9));
	}
	
	public void enterFirstName()
	{
		driver.findElement(FirstName).sendKeys(crandname.setRandomFirstName(9));
	}
	
	public void enterMiddleName()
	{
		driver.findElement(MiddleName).sendKeys("Middle");
	}
	
	public void selectSuffix()
	{
		driver.findElement(Suffix).sendKeys("");
		
	}
	
	public void enterSSN()
	{
		driver.findElement(SSN).sendKeys(crandname.setSSN());
	}
	
	public void enterDOB()
	{
		driver.findElement(DOB).sendKeys("01/01/1980");
	}
	
	public void enterAlienNumber()
	{
		driver.findElement(AlienNumber).sendKeys("");	
		
	}
	
	public void selectGender()
	{
		
		Select gender=new Select(driver.findElement(Gender));
		gender.selectByVisibleText("Male");
	}
	
	public void clickSearch()
	{
		driver.findElement(Search).click();
	}

}
