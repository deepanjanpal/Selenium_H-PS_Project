package abms_pages;

 

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;

public class SelectPrograms {

	WebDriver driver;
	
	public SelectPrograms(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By AAP=By.id("0");
	By ChildCare=By.id("1");
	By FosterCare=By.id("2");
	By Homeless_Perm=By.id("3");
	By ImmediateNeed=By.id("4");
	By Learn=By.id("5");
	By PE=By.id("6");
	By SNAP=By.id("7");
	By WelfaretoWork=By.id("8");
	By CAPI=By.id("0");
	By Diversion=By.id("1");
	By GeneralAssistance=By.id("2");
	By Homeless_Temp=By.id("3");
	By KinGap=By.id("4");
	By Medicaid=By.xpath("//input[@name='selectedProgram' and @type='checkbox' and @value='MC']");
	By RCA=By.id("6");
	By TANF=By.id("7");
	
	By Select=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[1]/img");
	By Cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[2]/img");
	
	public void selectMedicaid()
	{
		driver.findElement(Medicaid).click();;
	}
	
	public void selectSNAP()
	{
		driver.findElement(SNAP);
	}
	
	public void selectTANF()
	{
		driver.findElement(TANF);
	}
	
	public void selectChildCare()
	{
		driver.findElement(ChildCare);
	}
	/*	public void selectProgram(String text)
	{
	List<WebElement> chkbox=driver.findElements(By.xpath("//input[@name='selectedProgram' and @type='checkbox' and @value='MC']"));
	{
	
	for(int i=0;i<chkbox.size();i++)
	{
		WebElement local=chkbox.get(i);
		String val=local.getAttribute("value");
		
		if (val.equalsIgnoreCase("MC"))
		{
			local.click();
		}
		
		else if (val.equalsIgnoreCase("FS"))
		{
			local.click();
		}
		
		else if(val.equalsIgnoreCase("CW"))
		{
			local.click();
		}
	}
	}
	}	*/
	public void clickSelect()
	{
		driver.findElement(Select).click();
	}
	
	public void clickCancel()
	{
		driver.findElement(Cancel).click();
	}
			
	}
