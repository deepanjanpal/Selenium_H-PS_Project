package abms_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class ABMSLoginPage {
	
	WebDriver driver;
	
	
	By username=By.name("username");
	By password=By.xpath("/html/body/div[3]/form/table/tbody/tr/td[2]/table/tbody/tr[2]/td[2]/input[2]");
	By loginbutton=By.xpath("/html/body/div[3]/form/table/tbody/tr/td[2]/table/tbody/tr[5]/td[2]/input");
	
	public ABMSLoginPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void typeUserName()
	{
		driver.findElement(username).sendKeys("apsp.user");
	}
	
	public void typePassword()
	{
		driver.findElement(password).sendKeys("apsp4Security");
		
	}
	
	public void clickLogin()
	{
		driver.findElement(loginbutton).click();
	}

}
