package abms_pages;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;


public class SelectRequestedMedicaidType {
	
	WebDriver driver;
	
	public SelectRequestedMedicaidType(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By RequestedTypePrimary=By.id("1079267");
	By RequestedTypeSecondary=By.id("1079268");
	
	By SaveandContinue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[1]/td/a[1]/img");
	By Cancel= By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[1]/td/a[2]/img");
	
	public void selectRequestMedPrimary()
	{
		Select prim=new Select(driver.findElement(RequestedTypePrimary));
		prim.selectByIndex(1);
	}
	
	public void selectRequestMedSecondary()
	{
		Select sec=new Select(driver.findElement(RequestedTypeSecondary));
		sec.selectByIndex(1);
	}
	
	public void SaveandContinue()
	{
		driver.findElement(SaveandContinue).click();
	}
}
