package abms_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class ABMS_HomePageonLogin {
	
	WebDriver driver;
	
	
	By Case_Info=By.id("caseinfo");
	By New_Application=By.id("New Application");
	
	public ABMS_HomePageonLogin(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void clickCaseInfo()
	{
		driver.findElement(Case_Info).click();
	}
	
	public void clickNew_Application()
	{
		driver.findElement(New_Application).click();
	}

}
