
public class Secondclass {

	public static void main(String[] args) {

		Firstclass a= new Firstclass();
		a.add();
		
	}

}
