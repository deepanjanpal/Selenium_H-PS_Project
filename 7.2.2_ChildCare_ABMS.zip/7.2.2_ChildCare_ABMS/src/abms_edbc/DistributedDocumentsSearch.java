package abms_edbc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class DistributedDocumentsSearch {
	
	WebDriver driver;
	public DistributedDocumentsSearch(WebDriver driver)
	{
		this.driver=driver;
	}
	
By doc=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[1]/tbody/tr[2]/td[3]/a");

public void clicDoc()
{
	driver.findElement(doc).click();
}

	
}
