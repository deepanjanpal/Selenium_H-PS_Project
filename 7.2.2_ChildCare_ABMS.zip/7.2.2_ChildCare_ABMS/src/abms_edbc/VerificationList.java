package abms_edbc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class VerificationList {
	
	WebDriver driver;
	public VerificationList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By selectAll=By.id("select");
	By Verify=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[3]/table[3]/tbody/tr/td[1]/a/img");
	
	By RequestVerification=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[3]/table[3]/tbody/tr/td[2]/div/a/img");
	
public void clickSelectAll()
{
	driver.findElement(selectAll).click();
}

public void clickVerify()
{
	driver.findElement(Verify).click();
}

public void clickRequestVerification()
{
	driver.findElement(RequestVerification).click();
}

}
