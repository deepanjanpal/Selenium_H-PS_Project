package abms_edbc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class RunEDBC {
	
	WebDriver driver;
	public RunEDBC(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By selectAllEDBC=By.id("RunEDBCSelectAll");
	By RunEDBC=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr/td[2]/div[1]/a/img");
	By Cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr/td[3]/a/img");
	
	
	public void selectAllEDBC()
	{
		driver.findElement(selectAllEDBC).click();
	}
	
	public void clickEDBC()
	{
		driver.findElement(RunEDBC).click();
	}
	
	public void clickCancel()
	{
		driver.findElement(Cancel).click();
	}
	
	
	


}
