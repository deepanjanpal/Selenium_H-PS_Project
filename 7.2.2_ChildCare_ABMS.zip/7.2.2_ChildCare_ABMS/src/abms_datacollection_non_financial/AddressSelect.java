package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AddressSelect {
	
	WebDriver driver;
	
	public AddressSelect(WebDriver driver)
	{
		this.driver=driver;
	}

	
	By select=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table[1]/tbody/tr/td/table[1]/tbody/tr/td[2]/a[1]/img");
	
	public void clickSelect()
	{
		driver.findElement(select).click();
	}
}
