package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class ContactSummary {

	WebDriver driver;
	
	public ContactSummary(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By View=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[2]/tbody/tr/td[4]/a/img");
	By SearchAddress=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr/td[1]/a/img");
			
	By Add=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr/td[2]/a/img");
	
	By Edit=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[4]/tbody/tr[2]/td[7]/a/img");
	
	By Continue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table[1]/tbody/tr/td[2]/a/img");
	
	public void clickAdd()
	{
		driver.findElement(Add).click();
	}
	
	
}
