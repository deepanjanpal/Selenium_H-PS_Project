package abms_datacollection_non_financial;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class RelationshipDetail {
	
	WebDriver driver;
	
	public RelationshipDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By firstindiv=By.id("personId");
	By relationshiptype=By.id("typeCode");
	By secondindiv=By.id("person2Id");
	By hasparentalcontrol=By.id("label_parentalControl");
	By persondobasbegindate=By.id("label_dobAsBeginDate");
	By begindate=By.id("beg_date");
	By enddate=By.id("endDate");
	By verified=By.id("verifTypeCode");
	
	By saveandanother=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[1]/img");
	By saveandreturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[2]/img");
	
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[3]/img");
	
	
	public void selectfirstIndiv()
	{
		Select firindiv=new Select(driver.findElement(firstindiv));
		firindiv.selectByIndex(2);
	}
	
	public void selectRelationshipType()
	{
		Select relationshiptyp=new Select(driver.findElement(relationshiptype));
		relationshiptyp.selectByVisibleText("Parent (Biological/Adoptive)");
	}
	
	public void selectsecondIndiv()
	{
		Select secondind=new Select(driver.findElement(secondindiv));
		secondind.selectByIndex(1);
	}
	
	public void selecthasParentalControl()
	{
		driver.findElement(hasparentalcontrol).click();
	}
	
	public void selectDOBasBD()
	{
		driver.findElement(persondobasbegindate);
	}
	
	public void enterBeginDate()
	{
		driver.findElement(begindate).sendKeys("01/01/2012");
	}
	
	public void enterEndDate()
	{
		driver.findElement(enddate);
	}
	
	public void selectVerified()
	{
		Select verif=new Select(driver.findElement(verified));
		verif.selectByIndex(1);
	}
	
	public void clickSaveandAddAnother()
	{
		driver.findElement(saveandanother).click();
	}
	
	public void clickSaveandReturn()
	{
		driver.findElement(saveandreturn).click();
	}
	
	public void clickCancel()
	{
		driver.findElement(cancel).click();
	}
	

}
