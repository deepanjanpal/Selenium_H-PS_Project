package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class VitalStatisticsList {
	
	WebDriver driver;
	
	public VitalStatisticsList(WebDriver driver)
	{
	this.driver=driver;
	}
	
	By primhyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/a");
	By sechyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[3]/td[3]/a");
	By thirdhyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[4]/td[3]/a");
	
	By primEdit=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[2]/td[7]/a/img");
	By secEdit=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[3]/td[7]/a/img");
	By thirdEdit=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr[4]/td[7]/a/img");
	
	By Continue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[1]/td/table/tbody/tr/td[2]/a/img");
	By add=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[2]/td/table/tbody/tr/td/a/img");
	public void clickprimHyperlink()
	{
		driver.findElement(primhyperlink).click();
	}
	
	public void clicksecHyperlink()
	{
		driver.findElement(sechyperlink).click();
	}
	
	public void clickthirdHyperlink()
	{
		driver.findElement(thirdhyperlink).click();
	}

	public void clickEditPrimary()
	{
		driver.findElement(primEdit).click();
	}
	
	public void clickEditSecondary()
	{
		driver.findElement(secEdit).click();
	}
	
	public void clickEditTertiary()
	{
		driver.findElement(thirdEdit).click();
	}
	
	public void clickContinue()
	{
		driver.findElement(Continue).click();
	}
	
	public void clickAdd()
	{
		driver.findElement(add).click();
	}
}
