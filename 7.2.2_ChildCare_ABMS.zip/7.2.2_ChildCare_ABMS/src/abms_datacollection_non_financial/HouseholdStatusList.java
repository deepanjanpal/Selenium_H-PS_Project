package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HouseholdStatusList {

	WebDriver driver;
	
	public HouseholdStatusList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By primApplicanthyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr[2]/td[2]/a");
	By secApplicanthyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr[3]/td[2]/a");
	
	By editPrimary=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr[2]/td[7]/a/img");
	By editSecondary=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr[3]/td[7]/a/img");
	
	By add=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[2]/tbody/tr/td/a/img");
     
	By view=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[1]/tbody/tr/td[4]/a/img");

    By Continue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table[1]/tbody/tr/td[2]/a/img");

    public void clickPrimApplicant()
    {
    	driver.findElement(primApplicanthyperlink).click();
    }
    
    public void clickSecApplicant()
    {
    	driver.findElement(secApplicanthyperlink).click();
    }
    
    public void editPrimaryApplicant()
    {
    	driver.findElement(editPrimary).click();
    }
    
    public void editSecApplicant()
    {
    	driver.findElement(secApplicanthyperlink).click();
    }
    
    public void clickAdd()
    {
    	driver.findElement(add).click();
    }
    
    public void clickView()
    {
    	driver.findElement(view).click();
    }
    
    public void clickContinue()
    {
    	driver.findElement(Continue).click();
    }
}
