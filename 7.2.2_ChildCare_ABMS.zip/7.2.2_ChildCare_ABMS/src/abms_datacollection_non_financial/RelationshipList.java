package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RelationshipList {

	WebDriver driver;
	
	public RelationshipList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By edit=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[3]/tbody/tr[2]/td[9]/a/img");
	
	By add=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[2]/tbody/tr/td/a/img");
	
	By view=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form[2]/table[1]/tbody/tr/td[5]/a/img");
	
	By continu=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/table[1]/tbody/tr/td[2]/a/img");
	
	public void clickEdit()
	{
		driver.findElement(edit).click();
	}
	
	public void clickAdd()
	{
		driver.findElement(add).click();
	}
	
	public void clickView()
	{
		driver.findElement(view).click();
	}
	
	public void clickContinue()
	{
		driver.findElement(continu);
	}
			
}
