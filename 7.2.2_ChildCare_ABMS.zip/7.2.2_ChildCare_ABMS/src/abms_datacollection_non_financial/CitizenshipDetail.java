package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CitizenshipDetail {

	WebDriver driver;
	
	public CitizenshipDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By name=By.id("caseMembers");
	By nameuponusentry=By.id("name_upon_us_entry");
	By insdocument=By.id("INS_Document");
	By sectioncode=By.id("sect_code");
	By docpassportexpirationdate=By.id("Document_Passport_Expiration_Date");
	
	By i94_number=By.id("I-94_Number");
	By sevisidnumber=By.id("SEVIS_ID");
	By prucolreason=By.id("prucol_rsn_code");
	By insissuedate=By.id("ins_doc_issue_date");
	By insexpirationdate=By.id("ins_doc_expire_date");
	By dateofentry=By.id("country_entry_date");
	By insadjustmentdate=By.id("ins_adjustment_date");
	By livingsince1996=By.id("citizenshipLivingSince96Ind");
	By firstlastnamesame=By.id("sameNameIndicator");
	By firstname=By.id("insDocFirstName");
	By lastname=By.id("insDocLastName");
	By middlename=By.id("insDocMiddleName");
	By citverified=By.id("generalVerification");
	By sponsored=By.id("spnsr_ind");
	By nameofsponsor= By.id("alien_spnsr_name");
	By sponsorverified=By.id("sponsoredVerif");
	By battered=By.id("battrd_alien_ind");
	By batteredverified=By.id("batteredVerif");
	By indworked40hoursormore=By.id("forty_qtrs_ind");
	By indworked40hoursormoreverified=By.id("quartersVerif");
	By hmonglao=By.id("hmong_lao_ind");
	By hmonglaoverified=By.id("hmongVerif");
	By indonactiveduty=By.id("active_duty_ind");
	By indonactivedutyverified=By.id("activeDutyVerif");
	By relationshiptoActiveduty=By.id("relshpInd");
	By secondarysavestatus=By.id("second_save_stat_code");
	By begindate=By.id("beg_date");
	By enddate=By.id("end_date");
	By saveandreturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[11]/tbody/tr/td[2]/a[1]/img");
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[11]/tbody/tr/td[2]/a[2]/img");
	
	public void selectName()
	{
		Select nam=new Select(driver.findElement(name));
		nam.selectByIndex(1);
	}
	
	public void enternameuponUSEntry()
	{
		driver.findElement(nameuponusentry).sendKeys("");
	}
	
	public void selectINSDocument()
	{
	Select insdoc=new Select(driver.findElement(insdocument));
	insdoc.selectByVisibleText("");
	}
	
	public void sectionCode()
	{
		Select seccode=new Select(driver.findElement(sectioncode));
		seccode.selectByVisibleText("");
	}
	
	public void enteri94number()
	{
		driver.findElement(i94_number).sendKeys("");
	}
	
	public void enterdocpassexpirationdate()
	{
		driver.findElement(docpassportexpirationdate).sendKeys("");
	}
	
	public void enterSEVISID()
	{
		driver.findElement(sevisidnumber).sendKeys("");
	}
	
	public void selectPRUCOLReason()
	{
		Select prucreason=new Select(driver.findElement(prucolreason));
		prucreason.selectByVisibleText("");
	}
	
	public void enterinsissuedate()
	{
		driver.findElement(insissuedate).sendKeys("");
	}
	
	public void enterinsexpirationdate()
	{
		driver.findElement(insexpirationdate).sendKeys("");
	}
	
	public void enterdateofentry()
	{
		driver.findElement(dateofentry).sendKeys("");
	}
	
	public void enterINSAdjustmentDate()
	{
		driver.findElement(insadjustmentdate).sendKeys("");
	}
	
	public void livingsince1996()
	{
		Select livsin1996=new Select(driver.findElement(livingsince1996));
		livsin1996.selectByVisibleText("");
	}
	
	public void firstlastnameSame()
	{
		Select firlastname=new Select(driver.findElement(firstlastnamesame));
		firlastname.selectByIndex(1);
	}
	
	public void enterFirstName()
	{
		driver.findElement(firstname).sendKeys("");
	}
	
	public void enterLastName()
	{
		driver.findElement(lastname).sendKeys("");
	}
	
	public void enterMiddleName()
	{
		driver.findElement(middlename).sendKeys("");
	}
	
	public void selectVerified()
	{
		Select ver=new Select(driver.findElement(citverified));
		ver.selectByIndex(1);
	}
	
	
}
