package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HouseholdStatusDetail {

	WebDriver driver;
	
	public HouseholdStatusDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By name=By.id("casePersId");
	By livinginthehome=By.id("statusCode");
	By hhstatusmcexceptions=By.id("statOverrdCode");
	By begindate=By.id("beg_date");
	By enddate=By.id("end_date");
	
	By saveandaddanother=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[2]/td/a[1]/img");
	
	By saveandreturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[2]/td/a[2]/img");
	
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr/td[2]/a[3]/img");
	
	public void selectName()
	{
		Select nam=new Select(driver.findElement(name));
		nam.selectByIndex(1);
	}
	
	public void selectHouseholdStatus()
	{
		Select hstatus=new Select(driver.findElement(livinginthehome));
		hstatus.selectByIndex(1);
	}
	
	public void hhmcexceptions()
	{
		Select hhexcept=new Select(driver.findElement(hhstatusmcexceptions));
		hhexcept.selectByIndex(1);
	}
	
	public void enterBeginDate()
	{
		driver.findElement(begindate).sendKeys("");
	}
	
	public void enterEndDate()
	{
		driver.findElement(enddate);
	}
}
