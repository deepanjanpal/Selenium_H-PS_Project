package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class IndividualDemographicsDetail {
	
	WebDriver driver;
	
	public IndividualDemographicsDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By lastname=By.id("lastName");
	By firstname=By.id("firstName");
	By middlename=By.id("middleName");
	By maidenname=By.id("maidenName");
	By sufix=By.id("nameSuffix");
	By verified=By.id("verifyCodeName");
	
	By ssn=By.id("ssn");
	By ssnsightverified=By.id("ssnStatusCode");
	By aliennumber=By.id("alienNumber");
	By sufficientinfoforcin=By.id("sufficientInfoForCin");
	By Searchcin=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[3]/td[2]/a/img");
	By maritalstatus=By.id("maritalStatusCode");
	By gender=By.id("gender");
	By DOB=By.id("dateOfBirth");
	By verifiedDOB=By.id("verifyBirthDateCodeForValidation");
	By birthcountry=By.id("birthCountryCode");
	By countryverified=By.id("verifyBirthCountryCodeForValidation");
	By hispaniclatino=By.id("hispanicIndicatorCode");
	By driverlicensenumber=By.id("driversLicense");
	
	By race_white=By.id("label_raceCategoryCode_01");
	By language=By.id("primaryLanguageCode");
	By correspondenceinEnglish=By.id("correspondenceLanguageIndicator");
	
	By duplicatelist=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[9]/tbody/tr/td/a[1]/img");
	By saveandreturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[9]/tbody/tr/td/a[2]/img");
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[9]/tbody/tr/td/a[3]/img");
	
	
	public void enterLastName()
	{
		driver.findElement(lastname).sendKeys("");
	}
	
	public void enterFirstName()
	{
		driver.findElement(firstname).sendKeys("");
	}
	
	public void enterMidName()
	{
		driver.findElement(middlename).sendKeys("");
	}
	
	public void enterMaidenName()
	{
		driver.findElement(maidenname).sendKeys("");
	}
	
	public void selectSuffix()
	{
		Select suf=new Select(driver.findElement(sufix));
		suf.selectByIndex(1);
	}
	
	public void enterVerified()
	{
		Select ver=new Select(driver.findElement(verified));
		ver.selectByIndex(1);
	}
	
	public void enterSSN()
	{
		driver.findElement(ssn).sendKeys("");
	}
	
	public void ssnsightverified()
	{
		Select ssnsightver=new Select(driver.findElement(ssnsightverified));
		ssnsightver.selectByIndex(8);
	}
	
	public void enterAlienNumber()
	{
		driver.findElement(aliennumber).sendKeys("");
	}
	
    public void selectsufInfoforCIN()
    {
    	Select sufinfoselect=new Select(driver.findElement(sufficientinfoforcin));
    	sufinfoselect.selectByIndex(1);
    }
    
    public void SearchCin()
    {
    	driver.findElement(sufficientinfoforcin).click();
    
    	}
    
    public void maritalStatus()
    {
    	Select maritstatus=new Select(driver.findElement(maritalstatus));
    	maritstatus.selectByIndex(1);
}
    
    public void selectGender()
    {
    	Select gend=new Select(driver.findElement(gender));
    	gend.selectByIndex(1);
    }
    
    public void enterDOB()
    {
    	driver.findElement(DOB).sendKeys("");
    }
    
    public void enterbirthCountry()
    {
    	Select bircountry=new Select(driver.findElement(birthcountry));
    	bircountry.selectByIndex(3);
    }
    
    public void verifyDOB()
    {
    	Select vdob=new Select(driver.findElement(verifiedDOB));
    	vdob.selectByIndex(1);
    }
    
    public void verifyCountry()
    {
    	Select vcountry=new Select(driver.findElement(countryverified));
    	vcountry.selectByIndex(1);
    }
    
    public void selectHispanicLatino()
    {
    	Select hislatino=new Select(driver.findElement(hispaniclatino));
    	hislatino.selectByIndex(1);
    }
    
    public void enterdrivLicenseNumber()
    {
    	driver.findElement(driverlicensenumber).sendKeys("");
    }
    
    
    public void selectRaceWhite()
    {
    	driver.findElement(race_white).click();
    }

    public void selectprimLanguage()
    {
      Select primLanguage=new Select(driver.findElement(language));
      primLanguage.selectByIndex(1);

    }
    
    public void selectCorrespondenceinEnglish()
    {
    	Select corEnglish=new Select(driver.findElement(correspondenceinEnglish));
    	corEnglish.selectByIndex(1);
    }
    
    public void clickDuplicatelist()
    {
    	driver.findElement(duplicatelist).click();
    }
    
    public void clickSaveandReturn()
    {
    	driver.findElement(saveandreturn).click();
    }
    
    public void clickCancel()
    {
    	driver.findElement(cancel).click();
    }
    
    
	}
