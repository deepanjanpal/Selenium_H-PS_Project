package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class IndividualDemographicsList {
	
	WebDriver driver;
	
	public  IndividualDemographicsList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By prim_name_hyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[2]/td[3]/a");
	By sec_name_hyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[3]/td[3]/a");
	By third_name_hyperlink=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[3]/td[3]/a");

	By Edit_Primary=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[2]/td[7]/a/img");
	By Edit_Second=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[3]/td[7]/a/img");
	By Edit_Tertiary=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[4]/tbody/tr[4]/td[7]/a/img");
	
	By Continue=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr/td[2]/a/img");
	
	public void clickhyplinkPrimary()
	{
		driver.findElement(prim_name_hyperlink).click();
	}
	
	public void clickhyplinkSecondary()
	{
		driver.findElement(sec_name_hyperlink).click();
	}
	
	public void clickhyplinkTertiary()
	{
		driver.findElement(third_name_hyperlink).click();
	}
	
	public void clickEdit_Primary()
	{
		driver.findElement(Edit_Primary).click();
	}
	
	public void clickEdit_Second()
	{
		driver.findElement(Edit_Second).click();
	}
	
	public void clickEdit_Tertiary()
	{
		driver.findElement(Edit_Tertiary).click();
	}
}
