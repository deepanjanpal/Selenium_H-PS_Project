package abms_datacollection_non_financial;

import org.openqa.selenium.By;

import Utilities.GenerateAddress;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ContactSummaryEdit_AddressDetail {

	WebDriver driver;
	
	GenerateAddress gaddress=new GenerateAddress();
	public ContactSummaryEdit_AddressDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By addressappliesto=By.id("persId");
	By begindate=By.id("beg_date");
	By enddate=By.id("end_date");
	
	By addresstype=By.id("addressType");
	
	By addressline1=By.id("addressLine1");
	By addressline2=By.id("addressLine2");
	By city=By.id("city");
	By state=By.id("stateCode");
	By zipcode=By.id("zipCode");
	By county=By.id("addressCounty");
	
	By SaveandReturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[2]/tbody/tr/td/a[1]/img");
	By Cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[2]/tbody/tr/td/a[2]/img");
	
	public void selectApplicant()
	{
		Select addrappliesto=new Select(driver.findElement(addressappliesto));
		addrappliesto.selectByIndex(1);
		addrappliesto.selectByIndex(2);
	}
	
	public void enterBeginDate()
	{
		driver.findElement(begindate).sendKeys("01/01/2012");
	}
	
	public void enterEndDate()
	{
		driver.findElement(enddate).sendKeys("");
	}
	
	public void selectAddressType()
	{
		Select addrtype=new Select(driver.findElement(addresstype));
		addrtype.selectByIndex(1);
		addrtype.selectByIndex(2);
	}
	
	public void enteraddrLine1()
	{
		driver.findElement(addressline1).sendKeys(gaddress.setAddressLine1(10));
	}
	
	public void enteraddrLine2()
	{
		driver.findElement(addressline2).sendKeys(gaddress.setAddressLine2(5));
	}
	
	public void enterCity()
	{
		driver.findElement(city).sendKeys("Austin");
	}
		
	public void selectState()
	{
		Select stat=new Select(driver.findElement(state));
		stat.selectByVisibleText("TX");
		
	}
	
	public void enterzipCode()
	{
		driver.findElement(zipcode).sendKeys("78000");
	}
		public void selectCounty()
		{
			Select counti=new Select(driver.findElement(county));
			counti.selectByVisibleText("Napa");
		}
	
	public void clickSaveandReturn()
	{
		driver.findElement(SaveandReturn).click();
	}
	
	public void Cancel()
	{
		driver.findElement(Cancel).click();
	}
}
