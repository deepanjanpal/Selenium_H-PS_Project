package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class VItalStatisticsDetail {
	
	WebDriver driver;
	
	public VItalStatisticsDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By name=By.id("name");
	By wasthispersonborninusstate=By.id("usBornInd");
	By birthstate=By.id("birthState");
	
	By documenttypeonfile=By.id("citzDocType");
	By citizenshipverified=By.id("citizenshipVerified");
	By documentnumber=By.id("citzDocNumIdentif");
	
	By verified=By.id("vitalStatVerified");
	By countyofrecord=By.id("countyOfRecord");
	By save=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[9]/td/table/tbody/tr/td/a[1]/img");
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[9]/td/table/tbody/tr/td/a[2]/img");

	By close=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table/tbody/tr[1]/td/table/tbody/tr[1]/td[2]/table/tbody/tr/td/a[2]/img");
	
	public void selectName(int n)
	{
		Select nam=new Select(driver.findElement(name));
		nam.selectByIndex(n);
	}
	
	public void selectwasborninUsState()
	{
		Select qwasborninusstate=new Select(driver.findElement(wasthispersonborninusstate));
		qwasborninusstate.selectByIndex(2);
	}
	
	public void selectbirthState()
	{
		Select birstate=new Select(driver.findElement(birthstate));
		birstate.selectByIndex(1);
	}

	public void clickClose()
	{
		driver.findElement(close).click();
	}
	public void selectDocumentTypeonFile()
	{
		Select doctypeonfile=new Select(driver.findElement(documenttypeonfile));
		doctypeonfile.selectByIndex(1);
	}
	
	public void selectCitTypeVerified()
	{
		Select cittypeverified=new Select(driver.findElement(citizenshipverified));
		cittypeverified.selectByIndex(1);
	}
	
	public void enterDocNumber()
	{
		Select docnumber=new Select(driver.findElement(documentnumber));
		docnumber.selectByIndex(1);
	}
	
	public void vitalstatsVerified()
	{
		Select vitVerified=new Select(driver.findElement(verified));
		vitVerified.selectByIndex(2);
	}
	
	public void selectCounty()
	{
		Select conty=new Select(driver.findElement(countyofrecord));
		conty.selectByIndex(1);
	}
	
	public void clickSave()
	{
		driver.findElement(save).click();
	}
	
	public void clickCancel()
	{
		driver.findElement(cancel).click();
	}
	
	
}
