package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class PregnancyDetail {

	WebDriver driver;
	public PregnancyDetail(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By Mother=By.id("motherId");
	By Father=By.id("pers_father_id");
	By PresumptiveEligInidcator=By.id("presump_elig_card_ind");
	
	By numofunbornchildren=By.id("fetal_qty");
	By datereported=By.id("reportDateString");
	By duedate=By.id("expectDelivDateString");
	By termdate=By.id("termDateString");
	By saveandaddanother=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[1]/img");
	By saveandreturn=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[2]/img");
	By cancel=By.xpath("/html/body/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[2]/table/tbody/tr/td/form/table[1]/tbody/tr[1]/td[2]/a[3]/img");
	
	
	By verified=By.id("verifTypeCode");
	
	public void selectMother()
	{
		Select mothr=new Select(driver.findElement(Mother));
		mothr.selectByIndex(1);
	}
	
	public void selectFather()
	{
		Select fathr=new Select(driver.findElement(Father));
		fathr.selectByIndex(1);
	}
	
	public void presumptiveeligIndicator()
	{
		Select presindicator=new Select(driver.findElement(PresumptiveEligInidcator));
		presindicator.selectByIndex(1);
	}
	
	public void numofUnbornChildren()
	{
		driver.findElement(numofunbornchildren).sendKeys("");
	}
	
	public void dateReported()
	{
		driver.findElement(datereported).sendKeys("");
	}
	
	public void enterdueDate()
	{
		driver.findElement(duedate).sendKeys("");
	}
	
	public void entertermDate()
	{
		driver.findElement(termdate).sendKeys("");
	}
	
	public void selectVerified()
	{
		Select verif=new Select(driver.findElement(verified));
		verif.selectByIndex(1);
	}
	
	public void clickSaveandAddAnother()
	{
		driver.findElement(saveandaddanother).click();
	}
	
	public void clickSaveandReturn()
	{
		driver.findElement(saveandreturn).click();
	}
	
	public void clickCancel()
	{
		driver.findElement(cancel).click();
	}
}
