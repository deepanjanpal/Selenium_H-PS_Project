package abms_datacollection_non_financial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class ResidencyList {

	WebDriver driver;
	
	public ResidencyList(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
}
