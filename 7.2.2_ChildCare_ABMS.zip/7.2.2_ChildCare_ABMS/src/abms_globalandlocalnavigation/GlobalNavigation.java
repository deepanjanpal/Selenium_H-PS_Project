package abms_globalandlocalnavigation;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class GlobalNavigation {
	
	WebDriver driver;
	
	public GlobalNavigation(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By eligibility=By.xpath("/html/body/div[2]/div/ul/li[2]/a/span/span");
	
	By customer_information=By.xpath("/html/body/div[2]/div/div/div/ul/li[3]/a/span");
	
	public void clickEligibility()
	{
		driver.findElement(eligibility).click();
	}
	
	public void clickCustomerInformation()
	{
		driver.findElement(customer_information).click();
	}
	
	

}
