package com.Smoke.testcases;

public class StringTest {

	
	public static void main(String args[])
	{
		
		String sr="901-11-2374";
	StringReplace sreplace=new StringReplace();
	
	String s=sreplace.setSSN(sr);
	System.out.println(" " + s);
	}
}
