package com.Smoke.testcases;

import java.util.Iterator;
import java.util.Set;

import abms_datacollection_navigation.*;
import abms_edbc.*;
import abms_datacollection_non_financial.*;
import abms_pages.*;
import abms_globalandlocalnavigation.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;


public class FTest {

	@Test
	public void test()
	{
	
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\deepanjan.pal\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://asw-hps.accenture.com:7895/apsp/paa.portal");
		
		ABMS_HomePageonLogin abmslogin=new ABMS_HomePageonLogin(driver);
		ABMSLoginPage homepage=new ABMSLoginPage(driver);
		
		String mainwindow=driver.getWindowHandle();
		System.out.println("" + mainwindow);
		
		NewPersonSearch npersearch=new NewPersonSearch(driver);
		
		NewPersonSearchResults npersearchresults=new NewPersonSearchResults(driver);
		
		NewPersonDetail npersdetail=new NewPersonDetail(driver);
		
		CINSearchResults cinsearchresults=new CINSearchResults(driver);
		
		CaseMemberList cmemberlist=new CaseMemberList(driver);
		
		NewProgramDetail nprogdetail=new NewProgramDetail(driver);
		
		SelectPrograms sprogram=new SelectPrograms(driver);
		
		SelectRequestedMedicaidType sreqmedtype=new SelectRequestedMedicaidType(driver);
		
		PendingAssignment passignment=new PendingAssignment(driver);
		
		GlobalNavigation gnavigation=new GlobalNavigation(driver);
		
		ContactSummary csummary=new ContactSummary(driver);
		
		ContactSummaryEdit_AddressDetail csummaryeditdetail=new ContactSummaryEdit_AddressDetail(driver);
		
		AddressSelect adselect=new AddressSelect(driver);
		
		ABMS_DC_Navigation dcnav=new ABMS_DC_Navigation(driver);
		
		IndividualDemographicsList inddemolist=new IndividualDemographicsList(driver);
		
		IndividualDemographicsDetail inddemodetail=new IndividualDemographicsDetail(driver);
		
		VitalStatisticsList vslist=new VitalStatisticsList(driver);
		
		VItalStatisticsDetail vsdetail=new VItalStatisticsDetail(driver);
		
		RelationshipList rlist=new RelationshipList(driver);
		
		RelationshipDetail rdetail=new RelationshipDetail(driver);
		
		VerificationList vlist=new VerificationList(driver);
		
		RunEDBC redbc=new RunEDBC(driver);
		
		EDBCList elist=new EDBCList(driver);
		
		MedicaidEDBCSummary msummary=new MedicaidEDBCSummary(driver);
		
		DistributedDocumentsSearch dsearch=new DistributedDocumentsSearch(driver);
		
		
		homepage.typeUserName();
		homepage.typePassword();
		homepage.clickLogin();
		
		
		abmslogin.clickCaseInfo();
		abmslogin.clickNew_Application();
		
		npersearch.enterLastName();
		npersearch.enterFirstName();
		npersearch.enterDOB();
		npersearch.enterSSN();
		npersearch.selectGender();
		npersearch.clickSearch();
		
		npersearchresults.clickAddNewPerson();
		npersdetail.clickSearch();
		
		cinsearchresults.clickRequestNewCIN();
		
		npersdetail.clickSaveandContinue();
		
		cmemberlist.clickAddPerson();
		
		npersearch.enterLastName();
		npersearch.enterFirstName();
		npersearch.enterDOB();
		npersearch.enterSSN();
		npersearch.selectGender();
		npersearch.clickSearch();
		
		npersearchresults.clickAddNewPerson();
		npersdetail.clickSearch();
		
		cinsearchresults.clickRequestNewCIN();
		
		npersdetail.clickSaveandContinue();
		
		cmemberlist.clickSaveandContinue();
		
		nprogdetail.selectPrimary();
		
		nprogdetail.dateofApplication();
		nprogdetail.clickAddPrimar();
		
		sprogram.selectMedicaid();
		sprogram.selectSNAP();
		sprogram.selectTANF();
		sprogram.selectChildCare();
		sprogram.clickSelect();
		
		nprogdetail.clickAddSecond();
		sprogram.selectMedicaid();
		sprogram.selectSNAP();
		sprogram.selectTANF();
		sprogram.selectChildCare();
		sprogram.clickSelect();
		
		nprogdetail.SaveandContinue();
		
		sreqmedtype.SaveandContinue();
		
		passignment.clickselectAll();
		
		passignment.clickAssign();
		
		gnavigation.clickEligibility();
		
		gnavigation.clickCustomerInformation();
		
		csummary.clickAdd();
		
		csummaryeditdetail.selectApplicant();
		
		csummaryeditdetail.selectAddressType();
		
		csummaryeditdetail.enteraddrLine1();
		
		csummaryeditdetail.enteraddrLine2();
		csummaryeditdetail.enterCity();
		csummaryeditdetail.selectState();
		
		csummaryeditdetail.enterBeginDate();
		
		csummaryeditdetail.enterzipCode();
		
		csummaryeditdetail.selectCounty();
		
		csummaryeditdetail.clickSaveandReturn();
		
		adselect.clickSelect();
		
		dcnav.clickIndDemo();
		
		inddemolist.clickEdit_Primary();
		
		inddemodetail.ssnsightverified();
		
		inddemodetail.enterbirthCountry();
		
		inddemodetail.selectHispanicLatino();
		
		inddemodetail.selectRaceWhite();
		
		inddemodetail.clickSaveandReturn();
		
		inddemolist.clickEdit_Second();
		
        inddemodetail.ssnsightverified();
		
		inddemodetail.enterbirthCountry();
		
		inddemodetail.selectHispanicLatino();
		
		inddemodetail.selectRaceWhite();
		
		inddemodetail.clickSaveandReturn();
		
		dcnav.clickVitalStats();
		
		vslist.clickAdd();
		
		
		vsdetail.selectName(1);
		
		vsdetail.selectwasborninUsState();
		vsdetail.selectbirthState();
		
		vsdetail.vitalstatsVerified();
		
		vsdetail.clickSave();
		
		vsdetail.clickClose();
		vslist.clickAdd();
		
        vsdetail.selectName(1);
		
		vsdetail.selectwasborninUsState();
		vsdetail.selectbirthState();
		
		vsdetail.vitalstatsVerified();
		
		vsdetail.clickSave();
		
		dcnav.clickRelationship();
		
		rlist.clickAdd();
		
		rdetail.selectfirstIndiv();
		
		rdetail.selectRelationshipType();
		
		rdetail.selectsecondIndiv();
		
		rdetail.enterBeginDate();
		
		rdetail.clickSaveandReturn();
		
		dcnav.clickVerifications();
		
		vlist.clickSelectAll();
		vlist.clickVerify();
		
		dcnav.clickRunEDBC();
		
		redbc.selectAllEDBC();
		
		redbc.clickEDBC();
		
	    elist.medicaid();
		
	    msummary.clickAccept();
	    
	    elist.SaveandContinue();
	    
	    dsearch.clicDoc();
	    
	    String wid=driver.getWindowHandle();
	    
	    System.out.println("" + wid);
	    
	    Set<String> s=driver.getWindowHandles();
	    
	    Iterator it=s.iterator();
	    String curwindowid;
	    while(it.hasNext())
	    {
	    	curwindowid=it.next().toString();
	    	if(!curwindowid.equals(wid))
	    	{
	    		driver.switchTo().window(curwindowid);
	    	}
	    	
	    }
	    
	    Assert.assertEquals("Form",driver.getPageSource());
	    
	    
	    
	    
	    
	    
	    
		//driver.quit();
	}
}
