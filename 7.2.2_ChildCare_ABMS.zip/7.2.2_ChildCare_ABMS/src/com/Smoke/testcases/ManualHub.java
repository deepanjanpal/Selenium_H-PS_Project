package com.Smoke.testcases;

import java.io.File;

import abms_pages.ABMS_HomePageonLogin;
import abms_pages.ABMSLoginPage;
import abms_pages.NewPersonSearch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class ManualHub {

	@Test
	public void test()
	{
	
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\deepanjan.pal\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://asw-hps.accenture.com:9606/apsp/paa.portal");
		
		ABMS_HomePageonLogin abmslogin=new ABMS_HomePageonLogin(driver);
		ABMSLoginPage homepage=new ABMSLoginPage(driver);
		NewPersonSearch nperssearch=new NewPersonSearch(driver);
		
		homepage.typeUserName();
		homepage.typePassword();
		homepage.clickLogin();
		
		
		abmslogin.clickCaseInfo();
		abmslogin.clickNew_Application();
		
		nperssearch.enterLastName();
		nperssearch.enterFirstName();
		nperssearch.enterSSN();
		nperssearch.selectGender();
		nperssearch.clickSearch();
		
		//driver.quit();
	}
}


