package com.Smoke.testcases;

public class Raw

{  
public static void main(String args[]){  
String s1="901-55-4644";  
String replaceString=s1.replace('9','6');//replaces all occurrences of 'a' to 'e'  
System.out.println(replaceString);  
}

}  