package com.Smoke.testcases;

import org.apache.commons.lang3.RandomStringUtils;

public class StringReplace {
	
public String setSSN(String str)
	
	{
		String str2="";
		
		
		
		if(str.startsWith("9"))
		
			str2=str.replace('9', '6');
		
			
		
		
		String ssn=str2;
		
		return ssn;
	}



}



